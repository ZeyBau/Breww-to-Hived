# Unreleased (development copy, not deployed)

- Gift boxes go to `*_gifting_labels.csv` (same columns as the upload). An order is a gift box only when
  `FAO` in capitals appears as a separate word in a name, address line or delivery note. The existing
  `Gifting` manual-customer rule is unchanged and still sends those orders to manual processing.
- An FAO order with any unresolved problem goes to manual processing, flagged
  `Gift order: insert gift note and pack separately` (user decision, 28 Oct 2026, superseding the earlier
  "all FAO orders to the gifting file" rule).
- BYOB lines are packed from the subscriber's recipe in `byob_subscriber_lookup.csv` (see README "BYOB
  subscriber lookup"). Exact normalised name match against `Match Key`; REVIEW/MANUAL status, conflicts,
  invalid rows, duplicate keys, disallowed sizes or a missing lookup send the whole order to manual. The
  24-pack multiplier is applied only where the lookup allows it. `SPECIAL` is printed as `NAT`. The BYOB
  manual-product rule was removed from `settings.json` and `byob_lookup_file` added. Audit gains
  `BYOB decision`; lookup problems appear as `WARNING` lines in the validation report and a pop-up.
- Single bottles (`1 x 330ml Bottle - <flavour>`) are recognised. Each order's singles fill 6-bottle slots
  in flavour order (e.g. `2 × E`, `2 × RH`, `2 × PF` becomes one `2E, 2RH, 2PF` 6-carton); slots pack like
  6-packs, and only the last slot can be part-filled. The `Individual 330ml bottle` manual rule was removed
  from `settings.json`.
- `Shipping Class` = `next_day` is the final column of the upload, manual-processing and gifting files.
- Audit gains `Destination` and `Gift routing reason`; packing sequence gains `Destination` and includes
  gifting parcels; validation checks no order is split across destinations.

# Version 1.7

- Added `manual_customers` rules to `settings.json`.
- Orders whose delivery/customer name contains `gifting` are routed to full manual processing.
- Manual-customer matches are included in the manual queue, exception report, audit and full-weight reconciliation.

# Changelog

## v1.6

- Added Watermelon flavour with code `W`.
- Added aliases for `Zerbinati's Watermelon` and `Early access: Zerbinati's Watermelon`.
- Added generic parsing for Breww wholesale descriptions such as `Organic Elderflower Kombucha • 12x 330ml Bottles`.
- Retained full-manual placeholders for blank or genuinely unrecognised product data.

## v1.5

- Added `MOMO Kombucha Tote Bag` as a tote alias.
- Added `Mixed` as an alias of `Mixed Case`.
- Added a configurable `manual_products` rule for Build Your Own Box orders.
- BYOB orders now receive a `MANUAL` placeholder in the manual-processing CSV.
- Any completely or partially unrecognised order is moved to full manual processing rather than producing misleading partial labels.
- Added `Review category` and `Unrecognised / manual products` columns to the manual queue.
- Added a separate `unrecognised_and_manual_items.csv` exception report.
- Validation now confirms that every courier invoice appears in either automated or manual output.
- Full-manual placeholder rows carry the complete source order weight, preserving reconciliation.

## v1.4

- Breww total weights are treated as including tote and sock weights.
- Tote code: `TB`; sock code: `Sck`.
