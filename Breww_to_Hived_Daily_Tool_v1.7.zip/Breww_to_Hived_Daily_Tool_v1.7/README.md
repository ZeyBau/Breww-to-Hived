# Breww → Hived Daily Packing Tool — v1.5

A reusable local desktop app that converts the two daily Breww CSV exports into a parcel-level, pre-sorted Hived upload.

## Merchandise parcels

The app recognises these separately shipped items:

- MOMO Subscriber Tote Bag: code `TB`, weight `0.265 kg`
- Socks: code `Sck`, weight `0.050 kg`

Each unit becomes its own Hived upload row and therefore its own label. For example, an invoice containing one 24-bottle carton and two pairs of socks becomes:

- `24BO` — Box 1 of 3
- `Sck` — Box 2 of 3
- `Sck` — Box 3 of 3

The customer address and contact details are copied to every parcel row, and every parcel receives a unique carton reference.

## Important weight behaviour

Breww's `Total order weight` is now treated as the complete order weight, including tote bags and socks. The app therefore:

1. calculates the configured total weight of the separate tote/sock parcels;
2. subtracts that merchandise weight from Breww's total;
3. allocates only the remaining weight across the bottle cartons;
4. assigns `0.265 kg` to every `TB` row and `0.050 kg` to every `Sck` row;
5. verifies that all generated parcel rows add back to Breww's original total.

Example: if Breww reports `12.465 kg` for one 24-bottle carton plus one tote, the app generates approximately `12.200 kg` for the bottle carton and `0.265 kg` for the tote.

## Tote and sock matching

The tote matcher includes the exact known description:

```text
MOMO Subscriber Tote Bag - Your free gift will ship separately within 30 days of your order.
```

The sock export wording is not yet confirmed, so the current rule recognises descriptions containing `sock` or `socks`. The first live sock order should be checked in the product-mapping and validation outputs. An unrecognised product is diverted for manual review rather than silently assigned the wrong code.

## Simple settings format

Every flavour or separate item occupies one line in `settings.json`.

Example flavour:

```json
{"name": "Cherry", "code": "C", "priority": 8, "aliases": ["Cherry", "Organic Cherry"]}
```

Example separately shipped item:

```json
{"name": "Socks", "match_terms": ["sock", "socks"], "code": "Sck", "weight_kg": 0.050, "sort_priority": 1000}
```

To add a normal flavour, add one line to `flavours`. To add another separately shipped product, add one line to `separate_items`.

## Daily operation

1. Double-click `RUN_TOOL_WINDOWS.bat`.
2. Select the two current-day Breww CSV exports.
3. Enter the packing date.
4. Select the output location.
5. Click **Process today's orders**.
6. Review the manual-processing file and validation report.
7. Upload the generated `*_upload.csv` to Hived.

## Outputs

Each run creates a dated folder containing:

- `*_upload.csv` — final sorted Hived rows
- `*_manual_processing.csv` — genuine delivery instructions and uncertain mappings
- `*_packing_sequence.csv` — counts by parcel composition
- `*_order_audit.csv` — invoice-to-package and weight reconciliation
- `*_product_mapping.csv` — source descriptions and assigned codes
- `*_validation.txt` — label counts, invoice coverage and total-weight reconciliation
- `*_unrecognised_and_manual_items.csv` — every BYOB or unrecognised product line requiring manual attention

## Sorting

1. Carton size: 24, then 12, then 6
2. Full cartons before under-filled cartons
3. Single-flavour cartons before mixed cartons
4. Flavour/code priority
5. Separate merchandise after bottle cartons (`TB`, then `Sck`)
6. Invoice number

## Safety checks

The tool stops for missing columns, duplicate invoices, unmatched exports, non-positive configured merchandise weights, or a Breww total lower than the configured tote/sock weight. Genuine delivery instructions and uncertain products are diverted to the manual queue rather than silently processed.


## Guaranteed manual coverage

Build Your Own Box orders and any unrecognised product descriptions are not allowed to disappear from the outputs. The app creates one `MANUAL` placeholder row containing the full source order weight and raw product text. It also writes `*_unrecognised_and_manual_items.csv`, which lists every product line that blocked automatic processing.

The validation report states how many courier invoices were matched, how many are represented in the automated or manual files, and whether any invoice is missing from all outputs. The expected missing count is zero.


## Version 1.6 additions

- Watermelon is recognised as code `W`.
- The parser recognises wholesale descriptions ending in `• 6x/12x/24x 330ml Bottles`.
- Blank product fields and genuinely unknown products remain visible in the manual-processing and exception outputs.

## Manual customer/name rules

Orders can be routed to full manual processing based on the delivery/customer name. Each rule occupies one line in `settings.json`:

```json
{"name": "Gifting orders", "match_terms": ["gifting"], "reason": "The customer or delivery name indicates a gifting order, so the full order must be reviewed and processed manually."}
```

Matching is case-insensitive and checks both the delivery export's `Delivery name` and the order export's `Name`. A term such as `gifting` therefore matches `Gifting`, `GIFTING`, or names containing that word.

## Gift boxes (development copy, not yet deployed)

A gift box needs a physical gift note and is packed separately. An order is a gift box only when `FAO`, in capitals, appears as a separate word (e.g. `Acme Ltd FAO Jo`, `FAO: Jo`) in `Delivery name`, a delivery address line, city or county, the order `Name` or `Address`, or `Delivery notes`. Lower-case `fao`, `F.A.O.` and words containing FAO (`FAOS`) do not count. The word "gift" and the `Gifting` name rule above do not make an order a gift box.

A gift box with no other problem goes to `*_gifting_labels.csv`, which has the same columns as `*_upload.csv`; it does not appear in the upload or manual files. A gift box that also has an unresolved problem (unknown product, unresolved BYOB, a delivery instruction or a weight query) goes to the manual file instead, flagged `Gift order: insert gift note and pack separately`. Weight errors still stop the run.

## Single bottles (development copy, not yet deployed)

`1 x 330ml Bottle - <flavour>` lines are recognised. Each order's single bottles fill 6-bottle slots in flavour order, so `2 × Elderflower`, `2 × Raspberry-Hibiscus` and `2 × Passion Fruit` become one 6-carton coded `2E, 2RH, 2PF`. A slot packs like a 6-pack (it can share a 12 or 24 carton with the order's other packs), and only the last slot can be part-filled, e.g. 4 singles make a 6-carton holding 4 bottles. Single bottles of an unknown flavour still send the order to manual.

Every upload, manual and gifting row ends with `Shipping Class` = `next_day`.

## BYOB subscriber lookup (development copy, not yet deployed)

Build Your Own Box lines (`Build your own box - 6x/12x/24x Case`) are packed from each subscriber's recipe in the BYOB lookup.

**Where the lookup belongs.** Put the lookup CSV in this app folder, named exactly `byob_subscriber_lookup.csv` (the name is set by `byob_lookup_file` in `settings.json`; a full path also works). It contains subscriber names, so it must never be emailed around, committed to Git or copied into shared folders. CSV files in this folder are already excluded from Git.

**How to replace it.** Close the app, save the new lookup over `byob_subscriber_lookup.csv` (same name, same columns), and run the tool. The validation report shows which lookup was used (`BYOB lookup: <file> sha256:<first 12 characters> (<rows> rows)`), so you can confirm the new file was picked up. Keep the previous file elsewhere until the first run with the new one has been checked.

**Required columns:** `Match Key`, `Status`, `Ginger-Lemon`, `Turmeric`, `Elderflower`, `Raspberry-Hibiscus`, `Special / Limited`, `Blood Orange`, `Base Total Bottles`, `Allowed BYOB Sizes`, `24-pack Multiplier`, `Recipe Code`, `Recipe JSON`. Other columns (e.g. `Subscriber Name`, `Notes`) are ignored.

**Matching.** The subscriber is found by an exact match of the normalised name against `Match Key` (lower case, every space or punctuation run becomes one space; accents are kept). The tool tries the delivery export's `Delivery name`, the order export's `Name`, and the `Name:` line of the delivery notes. There is no fuzzy, partial or reordered matching, and recipient text such as `FAO Jo` is never removed to force a match. If two fields match different subscribers, the order goes to manual.

**When an order goes to manual.** The whole order goes to the manual-processing file when: the name is not in the lookup (`BYOB subscriber not found in lookup`); name fields match different subscribers; the row's `Status` is `REVIEW` or `MANUAL` (the tool never changes these); the row is invalid or its Match Key is duplicated; the ordered size is not allowed for that subscriber; or the lookup is missing or unreadable. In the last case a warning pops up and appears at the top of the validation report; ordinary orders are still processed normally.

**Sizes.** A recipe is used only for its own size (`Base Total Bottles`). A 24-bottle box from a 12-bottle recipe is allowed only when `Allowed BYOB Sizes` includes 24 and `24-pack Multiplier` is set (2 doubles every flavour). Ordering two 12-bottle boxes uses the 12-bottle recipe twice.

**SPECIAL = NAT.** The `SPECIAL` recipe category is a special flavour the packer chooses. It is printed as `NAT` on labels and packing descriptions (e.g. `4G, 4T, 4NAT`) and counts towards the box like any other bottle. It is not the Natoora product, which keeps its own code `NatooraMix`.

**Lookup checks.** On every run the tool checks: the required columns, non-blank and unique Match Keys, Status is AUTO/REVIEW/MANUAL, Recipe JSON uses only `G`, `T`, `E`, `RH`, `SPECIAL`, `BO` with whole non-negative counts, the flavour columns, Recipe JSON, Recipe Code and Base Total Bottles agree, and the allowed sizes and multiplier make sense. A row that fails is listed as a `WARNING` and is never used.

The order audit's `BYOB decision` column records the field and Match Key used, the lookup file hash and line, the base recipe, multiplier, ordered boxes and resulting bottles, or why the order went to manual.
