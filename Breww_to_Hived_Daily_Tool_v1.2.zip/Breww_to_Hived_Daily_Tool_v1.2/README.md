# Breww → Hived Daily Packing Tool — v1.5

A reusable local desktop app that converts the two daily Breww CSV exports into a parcel-level, pre-sorted Hived upload.

## Merchandise parcels

The app recognises these separately shipped items:

- MOMO Subscriber Tote Bag: code `TB`, weight `0.265 kg`
- Socks: code `Sck`, weight `0.050 kg`

Each unit becomes its own Hived upload row and therefore its own label. For example, an invoice containing one 24-bottle carton and two pairs of socks becomes:

- `24BO` — Box 1 of 3
- `Sck` — Box 2 of 3
- `Sck` — Box 3 of 3

The customer address and contact details are copied to every parcel row, and every parcel receives a unique carton reference.

## Important weight behaviour

Breww's `Total order weight` is now treated as the complete order weight, including tote bags and socks. The app therefore:

1. calculates the configured total weight of the separate tote/sock parcels;
2. subtracts that merchandise weight from Breww's total;
3. allocates only the remaining weight across the bottle cartons;
4. assigns `0.265 kg` to every `TB` row and `0.050 kg` to every `Sck` row;
5. verifies that all generated parcel rows add back to Breww's original total.

Example: if Breww reports `12.465 kg` for one 24-bottle carton plus one tote, the app generates approximately `12.200 kg` for the bottle carton and `0.265 kg` for the tote.

## Tote and sock matching

The tote matcher includes the exact known description:

```text
MOMO Subscriber Tote Bag - Your free gift will ship separately within 30 days of your order.
```

The sock export wording is not yet confirmed, so the current rule recognises descriptions containing `sock` or `socks`. The first live sock order should be checked in the product-mapping and validation outputs. An unrecognised product is diverted for manual review rather than silently assigned the wrong code.

## Simple settings format

Every flavour or separate item occupies one line in `settings.json`.

Example flavour:

```json
{"name": "Cherry", "code": "C", "priority": 8, "aliases": ["Cherry", "Organic Cherry"]}
```

Example separately shipped item:

```json
{"name": "Socks", "match_terms": ["sock", "socks"], "code": "Sck", "weight_kg": 0.050, "sort_priority": 1000}
```

To add a normal flavour, add one line to `flavours`. To add another separately shipped product, add one line to `separate_items`.

## Daily operation

1. Double-click `RUN_TOOL_WINDOWS.bat`.
2. Select the two current-day Breww CSV exports.
3. Enter the packing date.
4. Select the output location.
5. Click **Process today's orders**.
6. Review the manual-processing file and validation report.
7. Upload the generated `*_upload.csv` to Hived.

## Outputs

Each run creates a dated folder containing:

- `*_upload.csv` — final sorted Hived rows
- `*_manual_processing.csv` — genuine delivery instructions and uncertain mappings
- `*_packing_sequence.csv` — counts by parcel composition
- `*_order_audit.csv` — invoice-to-package and weight reconciliation
- `*_product_mapping.csv` — source descriptions and assigned codes
- `*_validation.txt` — label counts, invoice coverage and total-weight reconciliation
- `*_unrecognised_and_manual_items.csv` — every BYOB or unrecognised product line requiring manual attention

## Sorting

1. Carton size: 24, then 12, then 6
2. Full cartons before under-filled cartons
3. Single-flavour cartons before mixed cartons
4. Flavour/code priority
5. Separate merchandise after bottle cartons (`TB`, then `Sck`)
6. Invoice number

## Safety checks

The tool stops for missing columns, duplicate invoices, unmatched exports, non-positive configured merchandise weights, or a Breww total lower than the configured tote/sock weight. Genuine delivery instructions and uncertain products are diverted to the manual queue rather than silently processed.


## Guaranteed manual coverage

Build Your Own Box orders and any unrecognised product descriptions are not allowed to disappear from the outputs. The app creates one `MANUAL` placeholder row containing the full source order weight and raw product text. It also writes `*_unrecognised_and_manual_items.csv`, which lists every product line that blocked automatic processing.

The validation report states how many courier invoices were matched, how many are represented in the automated or manual files, and whether any invoice is missing from all outputs. The expected missing count is zero.


## Version 1.6 additions

- Watermelon is recognised as code `W`.
- The parser recognises wholesale descriptions ending in `• 6x/12x/24x 330ml Bottles`.
- Blank product fields and genuinely unknown products remain visible in the manual-processing and exception outputs.
