@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py breww_to_hived_tool.py
    goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python breww_to_hived_tool.py
    goto :end
)

echo.
echo Python was not found on this computer.
echo Install Python 3.11 or newer from python.org, then run this file again.
echo During installation, tick "Add Python to PATH".
echo.
pause

:end
endlocal
