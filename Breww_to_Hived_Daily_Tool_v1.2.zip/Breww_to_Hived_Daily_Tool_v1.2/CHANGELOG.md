# Changelog

## v1.6

- Added Watermelon flavour with code `W`.
- Added aliases for `Zerbinati's Watermelon` and `Early access: Zerbinati's Watermelon`.
- Added generic parsing for Breww wholesale descriptions such as `Organic Elderflower Kombucha • 12x 330ml Bottles`.
- Retained full-manual placeholders for blank or genuinely unrecognised product data.

## v1.5

- Added `MOMO Kombucha Tote Bag` as a tote alias.
- Added `Mixed` as an alias of `Mixed Case`.
- Added a configurable `manual_products` rule for Build Your Own Box orders.
- BYOB orders now receive a `MANUAL` placeholder in the manual-processing CSV.
- Any completely or partially unrecognised order is moved to full manual processing rather than producing misleading partial labels.
- Added `Review category` and `Unrecognised / manual products` columns to the manual queue.
- Added a separate `unrecognised_and_manual_items.csv` exception report.
- Validation now confirms that every courier invoice appears in either automated or manual output.
- Full-manual placeholder rows carry the complete source order weight, preserving reconciliation.

## v1.4

- Breww total weights are treated as including tote and sock weights.
- Tote code: `TB`; sock code: `Sck`.
