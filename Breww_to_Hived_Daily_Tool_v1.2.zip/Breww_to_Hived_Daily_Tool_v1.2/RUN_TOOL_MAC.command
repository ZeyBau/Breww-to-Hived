#!/bin/bash
cd "$(dirname "$0")"
python3 breww_to_hived_tool.py
