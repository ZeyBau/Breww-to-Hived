from __future__ import annotations

import csv
import json
import os
import re
import sys
import traceback
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path
from typing import Any

DELIVERY_REQUIRED = [
    "Invoice number", "Delivery name", "Delivery address first line",
    "Delivery address second line", "Delivery address city",
    "Delivery address county", "Delivery address postcode",
    "Delivery address country", "Total order weight", "Phone number",
    "Email address",
]
ORDER_REQUIRED = [
    "Type", "Order", "Name", "Address", "Drop start", "Drop end",
    "Delivery notes", "Products",
]
OUTPUT_COLUMNS = DELIVERY_REQUIRED + [
    "Order contents code", "Carton size", "Actual bottles", "Box",
    "Carton reference", "Readable contents", "Original order weight",
    "Excluded / separate items", "Route tag",
]
MANUAL_COLUMNS = OUTPUT_COLUMNS + [
    "Delivery instruction", "Manual reason", "Raw products",
]


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def load_settings() -> dict[str, Any]:
    path = app_dir() / "settings.json"
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    last_error = None
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            with path.open(encoding=encoding, newline="") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    raise ValueError(f"{path.name} has no header row.")
                return [
                    {(key or "").strip(): (value or "").strip() for key, value in row.items()}
                    for row in reader
                    if any((value or "").strip() for value in row.values())
                ]
        except UnicodeDecodeError as exc:
            last_error = exc
    raise ValueError(f"Could not read {path.name} as CSV: {last_error}")


def detect_file_roles(path_a: Path, path_b: Path) -> tuple[Path, Path]:
    def headers(path: Path) -> set[str]:
        rows = read_csv(path)
        return set(rows[0]) if rows else set()

    headers_a, headers_b = headers(path_a), headers(path_b)
    a_delivery = set(DELIVERY_REQUIRED).issubset(headers_a)
    b_delivery = set(DELIVERY_REQUIRED).issubset(headers_b)
    a_orders = set(ORDER_REQUIRED).issubset(headers_a)
    b_orders = set(ORDER_REQUIRED).issubset(headers_b)

    if a_delivery and b_orders:
        return path_a, path_b
    if b_delivery and a_orders:
        return path_b, path_a
    raise ValueError(
        "The two files could not be identified. One must contain delivery/address/weight "
        "columns and the other must contain Type, Order, Delivery notes and Products."
    )


def require_columns(rows: list[dict[str, str]], required: list[str], label: str) -> None:
    if not rows:
        raise ValueError(f"{label} contains no data rows.")
    missing = [column for column in required if column not in rows[0]]
    if missing:
        raise ValueError(f"{label} is missing: {', '.join(missing)}")


def invoice_number(value: str, label: str) -> int:
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text):
        raise ValueError(f"Invalid {label}: {value!r}")
    return int(text)


def float_value(value: str, invoice: int) -> float:
    try:
        result = float(str(value).strip().replace(",", ""))
    except ValueError as exc:
        raise ValueError(f"Invoice {invoice}: invalid weight {value!r}") from exc
    if result < 0:
        raise ValueError(f"Invoice {invoice}: weight cannot be negative")
    return result


def clean_note(note: str, prefixes: list[str]) -> str:
    lowered = tuple(prefix.casefold() for prefix in prefixes)
    kept = []
    for line in (note or "").splitlines():
        text = line.strip()
        if text and not text.casefold().startswith(lowered):
            kept.append(text)
    return " | ".join(kept)


def build_flavour_maps(settings: dict[str, Any]):
    alias_to_name: dict[str, str] = {}
    code_by_name: dict[str, str] = {}
    priority_by_name: dict[str, int] = {}
    for item in settings["flavours"]:
        name = item["name"]
        code_by_name[name] = item["code"]
        priority_by_name[name] = int(item["priority"])
        for alias in item.get("aliases", []) + [name]:
            alias_to_name[alias.casefold()] = name
    return alias_to_name, code_by_name, priority_by_name


def parse_product_line(line: str, settings: dict[str, Any]) -> dict[str, Any]:
    alias_to_name, code_by_name, _ = build_flavour_maps(settings)
    match = re.match(r"^\s*(\d+)\s*[×x]\s*(.*?)\s*$", line)
    quantity = int(match.group(1)) if match else 1
    description = match.group(2).strip() if match else line.strip()
    lower = description.casefold()

    if "subscriber tote bag" in lower:
        return {"quantity": quantity, "raw": description, "product": "Subscriber Tote Bag", "pack_size": 0, "extra_code": "", "status": "separate"}
    if "momo club welcome pack" in lower:
        return {"quantity": quantity, "raw": description, "product": "MOMO Club Welcome Pack", "pack_size": 0, "extra_code": "WP", "status": "extra"}
    if "gift kombucha subscription" in lower:
        return {"quantity": quantity, "raw": description, "product": "Mixed Case", "pack_size": 12, "extra_code": "", "status": "uncertain"}

    pack_match = re.search(r"(?<!\d)(6|12|24)\s*(?:x\s*330ml\s*bottle|bottle case|bottles?)", description, flags=re.I)
    pack_size = int(pack_match.group(1)) if pack_match else 0

    product = re.sub(r"(?i)^\d+\s*x\s*330ml\s*Bottle\s*-\s*", "", description)
    product = re.sub(r"(?i)^\d+\s*bottle case\s*-\s*", "", product)
    product = re.sub(r"(?i)^Organic\s+", "", product)
    product = re.sub(r"(?i)^Limited Edition\s+", "", product)
    product = re.sub(r"(?i)\s*-\s*(?:6|12|24)\s*bottles?$", "", product)
    product = re.sub(r"(?i)\s+Kombucha$", "", product).strip()
    standard = alias_to_name.get(product.casefold(), product)
    status = "confirmed" if pack_size in (6, 12, 24) and standard in code_by_name else "uncertain"
    return {"quantity": quantity, "raw": description, "product": standard, "pack_size": pack_size, "extra_code": "", "status": status}


def cartonize(units: list[dict[str, Any]], priority: dict[str, int]) -> list[dict[str, Any]]:
    key = lambda unit: (priority.get(unit["product"], 999), unit["product"])
    u24 = sorted([u.copy() for u in units if u["size"] == 24], key=key)
    u12 = sorted([u.copy() for u in units if u["size"] == 12], key=key)
    u6 = sorted([u.copy() for u in units if u["size"] == 6], key=key)
    cartons: list[list[dict[str, Any]]] = [[unit] for unit in u24]

    by_product: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in u12:
        by_product[unit["product"]].append(unit)
    leftovers12: list[dict[str, Any]] = []
    for product in sorted(by_product, key=lambda p: (priority.get(p, 999), p)):
        product_units = by_product[product]
        while len(product_units) >= 2:
            cartons.append([product_units.pop(0), product_units.pop(0)])
        leftovers12.extend(product_units)

    leftovers12.sort(key=key)
    while len(leftovers12) >= 2:
        cartons.append([leftovers12.pop(0), leftovers12.pop(0)])

    if leftovers12:
        base = leftovers12.pop(0)
        carton = [base]
        while u6 and len(carton) < 3:
            same = next((i for i, unit in enumerate(u6) if unit["product"] == base["product"]), None)
            carton.append(u6.pop(same if same is not None else 0))
        cartons.append(carton)

    by_product6: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in u6:
        by_product6[unit["product"]].append(unit)
    mixed6: list[dict[str, Any]] = []
    for product in sorted(by_product6, key=lambda p: (priority.get(p, 999), p)):
        product_units = by_product6[product]
        while len(product_units) >= 2:
            count = min(4, len(product_units))
            cartons.append([product_units.pop(0) for _ in range(count)])
        mixed6.extend(product_units)
    mixed6.sort(key=key)
    while mixed6:
        cartons.append([mixed6.pop(0) for _ in range(min(4, len(mixed6)))])

    output = []
    for carton_units in cartons:
        actual = sum(unit["size"] for unit in carton_units)
        capacity = 6 if actual <= 6 else 12 if actual <= 12 else 24
        output.append({"units": carton_units, "actual": actual, "capacity": capacity})
    return output


def carton_totals(carton: dict[str, Any]) -> Counter[str]:
    totals: Counter[str] = Counter()
    for unit in carton["units"]:
        totals[unit["product"]] += int(unit["size"])
    return totals


def carton_code(carton: dict[str, Any], codes: dict[str, str], priority: dict[str, int], extras: list[str]) -> str:
    components = [
        (bottles, codes.get(product, "UNK"), priority.get(product, 999))
        for product, bottles in carton_totals(carton).items()
    ]
    components.sort(key=lambda item: (-item[0], item[2], item[1]))
    tokens = [f"{bottles}{code}" for bottles, code, _ in components]
    tokens.extend(extras)
    return ", ".join(tokens)


def carton_description(carton: dict[str, Any], priority: dict[str, int], extras: list[str]) -> str:
    items = sorted(carton_totals(carton).items(), key=lambda item: (priority.get(item[0], 999), item[0]))
    result = " + ".join(f"{bottles} {product}" for product, bottles in items)
    if extras:
        result += " + " + " + ".join("MOMO Club Welcome Pack" if item == "WP" else item for item in extras)
    return result


def row_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        -int(row["Carton size"]),
        -int(row["Actual bottles"]),
        int(row["_mixed"]),
        int(row["_priority"]),
        str(row["Order contents code"]),
        int(row["Invoice number"]),
        str(row["Box"]),
    )


def write_rows(path: Path, columns: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def process_files(first_path: Path, second_path: Path, output_parent: Path, packing_date: str) -> Path:
    settings = load_settings()
    delivery_path, order_path = detect_file_roles(first_path, second_path)
    delivery_rows = read_csv(delivery_path)
    order_rows_all = read_csv(order_path)
    require_columns(delivery_rows, DELIVERY_REQUIRED, "Delivery export")
    require_columns(order_rows_all, ORDER_REQUIRED, "Order-content export")

    delivery_numbers = [invoice_number(row["Invoice number"], "invoice number") for row in delivery_rows]
    order_rows = [row for row in order_rows_all if row["Type"].casefold() == settings["delivery_type"].casefold()]
    order_numbers = [invoice_number(row["Order"], "order number") for row in order_rows]
    duplicate_deliveries = [number for number, count in Counter(delivery_numbers).items() if count > 1]
    duplicate_orders = [number for number, count in Counter(order_numbers).items() if count > 1]
    if duplicate_deliveries or duplicate_orders:
        raise ValueError(f"Duplicate invoices found. Delivery: {duplicate_deliveries}; orders: {duplicate_orders}")

    delivery_by_invoice = {invoice_number(row["Invoice number"], "invoice number"): row for row in delivery_rows}
    orders_by_invoice = {invoice_number(row["Order"], "order number"): row for row in order_rows}
    missing_delivery = sorted(set(orders_by_invoice) - set(delivery_by_invoice))
    missing_products = sorted(set(delivery_by_invoice) - set(orders_by_invoice))
    if missing_delivery or missing_products:
        raise ValueError(f"The exports do not match. Missing delivery data: {missing_delivery}; missing product data: {missing_products}")

    _, codes, priority = build_flavour_maps(settings)
    automated: list[dict[str, Any]] = []
    manual: list[dict[str, Any]] = []
    audit: list[dict[str, Any]] = []
    mappings: dict[str, dict[str, Any]] = {}

    for invoice in sorted(orders_by_invoice):
        delivery, order = delivery_by_invoice[invoice], orders_by_invoice[invoice]
        units: list[dict[str, Any]] = []
        extras_box1: list[str] = []
        separate_items: list[str] = []
        warnings: list[str] = []
        for line in (order.get("Products") or "").splitlines():
            if not line.strip():
                continue
            parsed = parse_product_line(line, settings)
            mappings[parsed["raw"]] = parsed
            if parsed["pack_size"] in (6, 12, 24):
                for _ in range(parsed["quantity"]):
                    units.append({"product": parsed["product"], "size": parsed["pack_size"]})
            elif parsed["status"] == "extra":
                extras_box1.extend([parsed["extra_code"]] * parsed["quantity"])
            elif parsed["status"] == "separate":
                separate_items.extend([parsed["product"]] * parsed["quantity"])
            else:
                warnings.append(f"Unmapped product: {parsed['raw']}")
            if parsed["status"] == "uncertain":
                warnings.append(f"Confirm mapping: {parsed['raw']}")

        cartons = cartonize(units, priority)
        total_bottles = sum(carton["actual"] for carton in cartons)
        original_weight = float_value(delivery["Total order weight"], invoice)
        instruction = clean_note(order.get("Delivery notes", ""), settings["ignore_delivery_note_prefixes"])
        manual_reasons = []
        if instruction:
            manual_reasons.append("Delivery instruction")
        if warnings:
            manual_reasons.append("Product mapping needs confirmation")

        generated_codes = []
        allocated_weight = 0.0
        for index, carton in enumerate(cartons, start=1):
            extras = extras_box1 if index == 1 else []
            code = carton_code(carton, codes, priority, extras)
            generated_codes.append(code)
            products = sorted(carton_totals(carton), key=lambda p: (priority.get(p, 999), p))
            carton_weight = original_weight * carton["actual"] / total_bottles if total_bottles else original_weight
            allocated_weight += carton_weight
            row = {column: delivery.get(column, "") for column in DELIVERY_REQUIRED}
            row.update({
                "Invoice number": str(invoice),
                "Total order weight": f"{carton_weight:.4f}",
                "Order contents code": code,
                "Carton size": carton["capacity"],
                "Actual bottles": carton["actual"],
                "Box": f"{index} of {len(cartons)}",
                "Carton reference": str(invoice) if len(cartons) == 1 else f"{invoice}-{index}of{len(cartons)}",
                "Readable contents": carton_description(carton, priority, extras),
                "Original order weight": f"{original_weight:.4f}",
                "Excluded / separate items": ", ".join(separate_items),
                "Route tag": order.get("Drop start", ""),
                "Delivery instruction": instruction,
                "Manual reason": "; ".join(manual_reasons),
                "Raw products": order.get("Products", ""),
                "_mixed": 0 if len(products) == 1 else 1,
                "_priority": priority.get(products[0], 999) if products else 999,
            })
            (manual if manual_reasons else automated).append(row)

        audit.append({
            "Invoice": invoice,
            "Customer": delivery["Delivery name"],
            "Generated codes": " | ".join(generated_codes),
            "Number of cartons": len(cartons),
            "Manual processing": "Yes" if manual_reasons else "No",
            "Manual reason": "; ".join(manual_reasons),
            "Source order weight": f"{original_weight:.4f}",
            "Allocated carton weight": f"{allocated_weight:.4f}",
            "Raw products": order.get("Products", ""),
        })

    automated.sort(key=row_sort_key)
    manual.sort(key=row_sort_key)
    for row in automated + manual:
        row.pop("_mixed", None)
        row.pop("_priority", None)

    out_dir = output_parent / f"Hived_Output_{packing_date}"
    out_dir.mkdir(parents=True, exist_ok=True)
    prefix = f"hived_{packing_date}"
    write_rows(out_dir / f"{prefix}_upload.csv", OUTPUT_COLUMNS, automated)
    write_rows(out_dir / f"{prefix}_manual_processing.csv", MANUAL_COLUMNS, manual)

    sequence_counts = Counter((row["Carton size"], row["Actual bottles"], row["Order contents code"], row["Readable contents"]) for row in automated)
    sequence_rows = []
    seen = set()
    for row in automated:
        key = (row["Carton size"], row["Actual bottles"], row["Order contents code"], row["Readable contents"])
        if key not in seen:
            seen.add(key)
            sequence_rows.append({"Carton size": key[0], "Actual bottles": key[1], "Order contents code": key[2], "Readable contents": key[3], "Number of labels": sequence_counts[key]})
    write_rows(out_dir / f"{prefix}_packing_sequence.csv", ["Carton size", "Actual bottles", "Order contents code", "Readable contents", "Number of labels"], sequence_rows)
    write_rows(out_dir / f"{prefix}_order_audit.csv", ["Invoice", "Customer", "Generated codes", "Number of cartons", "Manual processing", "Manual reason", "Source order weight", "Allocated carton weight", "Raw products"], audit)

    mapping_rows = [{
        "Raw Breww product description": raw,
        "Standard product": item["product"],
        "Pack size": item["pack_size"],
        "Code": codes.get(item["product"], item.get("extra_code", "")),
        "Status": item["status"],
    } for raw, item in sorted(mappings.items())]
    write_rows(out_dir / f"{prefix}_product_mapping.csv", ["Raw Breww product description", "Standard product", "Pack size", "Code", "Status"], mapping_rows)

    source_total = sum(float_value(row["Total order weight"], invoice_number(row["Invoice number"], "invoice number")) for row in delivery_rows)
    generated_total = sum(float(row["Total order weight"]) for row in automated + manual)
    validation = [
        f"Packing date: {packing_date}",
        f"Courier orders matched: {len(order_rows)}",
        f"Automated label rows: {len(automated)}",
        f"Manual label rows: {len(manual)}",
        f"Source total weight: {source_total:.4f} kg",
        f"Generated total weight: {generated_total:.4f} kg",
        f"Weight difference: {generated_total - source_total:.4f} kg",
        "",
        "Mixed order codes use comma separation, e.g. 12M, 6BO.",
        "Review the manual-processing CSV before uploading labels.",
    ]
    (out_dir / f"{prefix}_validation.txt").write_text("\n".join(validation), encoding="utf-8")
    return out_dir


def launch_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("Breww → Hived Daily Packing Tool")
    root.geometry("780x470")
    root.minsize(720, 430)

    first_var = tk.StringVar()
    second_var = tk.StringVar()
    output_var = tk.StringVar(value=str(Path.home() / "Desktop"))
    date_var = tk.StringVar(value=date.today().isoformat())
    status_var = tk.StringVar(value="Select the two daily Breww CSV exports.")

    frame = ttk.Frame(root, padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Breww → Hived Daily Packing Tool", font=("Segoe UI", 18, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
    ttk.Label(frame, text="Creates a sorted carton-level Hived upload, manual queue and audit files.").grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 20))

    def choose_csv(variable: tk.StringVar):
        path = filedialog.askopenfilename(title="Select Breww CSV", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if path:
            variable.set(path)

    def choose_output():
        path = filedialog.askdirectory(title="Choose output folder")
        if path:
            output_var.set(path)

    ttk.Label(frame, text="Breww CSV 1").grid(row=2, column=0, sticky="w")
    ttk.Entry(frame, textvariable=first_var).grid(row=3, column=0, columnspan=2, sticky="ew", padx=(0, 8))
    ttk.Button(frame, text="Browse…", command=lambda: choose_csv(first_var)).grid(row=3, column=2, sticky="ew")
    ttk.Label(frame, text="Breww CSV 2").grid(row=4, column=0, sticky="w", pady=(14, 0))
    ttk.Entry(frame, textvariable=second_var).grid(row=5, column=0, columnspan=2, sticky="ew", padx=(0, 8))
    ttk.Button(frame, text="Browse…", command=lambda: choose_csv(second_var)).grid(row=5, column=2, sticky="ew")
    ttk.Label(frame, text="Packing date (YYYY-MM-DD)").grid(row=6, column=0, sticky="w", pady=(14, 0))
    ttk.Entry(frame, textvariable=date_var, width=20).grid(row=7, column=0, sticky="w")
    ttk.Label(frame, text="Output location").grid(row=8, column=0, sticky="w", pady=(14, 0))
    ttk.Entry(frame, textvariable=output_var).grid(row=9, column=0, columnspan=2, sticky="ew", padx=(0, 8))
    ttk.Button(frame, text="Browse…", command=choose_output).grid(row=9, column=2, sticky="ew")

    def run_process():
        try:
            if not first_var.get() or not second_var.get():
                raise ValueError("Select both Breww CSV files.")
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_var.get().strip()):
                raise ValueError("Enter the packing date as YYYY-MM-DD.")
            status_var.set("Processing…")
            root.update_idletasks()
            output = process_files(Path(first_var.get()), Path(second_var.get()), Path(output_var.get()), date_var.get().strip())
            status_var.set(f"Complete: {output}")
            messagebox.showinfo("Processing complete", f"Files created in:\n{output}")
            try:
                os.startfile(output)  # type: ignore[attr-defined]
            except Exception:
                pass
        except Exception as exc:
            status_var.set("Processing stopped. See the error message.")
            messagebox.showerror("Could not process files", str(exc))

    ttk.Button(frame, text="Process today's orders", command=run_process).grid(row=10, column=0, columnspan=3, sticky="ew", pady=(24, 14), ipady=8)
    ttk.Separator(frame).grid(row=11, column=0, columnspan=3, sticky="ew", pady=(0, 12))
    ttk.Label(frame, textvariable=status_var, wraplength=720).grid(row=12, column=0, columnspan=3, sticky="w")
    ttk.Label(frame, text="Mixed codes are comma-separated, e.g. 12M, 6BO. Unknown products and genuine delivery notes are diverted to the manual file.", wraplength=720).grid(row=13, column=0, columnspan=3, sticky="w", pady=(10, 0))

    frame.columnconfigure(0, weight=1)
    frame.columnconfigure(1, weight=1)
    frame.columnconfigure(2, weight=0)
    root.mainloop()


if __name__ == "__main__":
    try:
        launch_gui()
    except Exception:
        error_path = app_dir() / "tool_error.txt"
        error_path.write_text(traceback.format_exc(), encoding="utf-8")
        raise
