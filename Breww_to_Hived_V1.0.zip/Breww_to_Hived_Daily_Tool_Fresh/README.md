# Breww → Hived Daily Packing Tool

A reusable local desktop app that converts the two daily Breww CSV exports into a carton-level, pre-sorted Hived upload.

## Outputs

Each run creates a dated folder containing:

- `*_upload.csv` — final sorted Hived rows
- `*_manual_processing.csv` — genuine delivery instructions and uncertain product mappings
- `*_packing_sequence.csv` — counts by carton composition
- `*_order_audit.csv` — invoice-to-carton reconciliation
- `*_product_mapping.csv` — descriptions and assigned codes
- `*_validation.txt` — counts and weight reconciliation

## Sorting

1. Carton size: 24, then 12, then 6
2. Full cartons before under-filled cartons
3. Single-flavour cartons before mixed cartons
4. Flavour/code priority
5. Invoice number

## Codes

- `24BO` = 24 Blood Orange
- `12M` = 12 Mixed Case
- `12M, 6BO` = 12 Mixed Case plus 6 Blood Orange
- `12BO, 12E` = 12 Blood Orange plus 12 Elderflower

The comma remains inside one CSV field and will not create extra columns.

## Safety checks

The tool stops when required columns are missing, invoices are duplicated or the two exports do not match. Genuine delivery instructions and uncertain products are placed in the manual queue rather than silently processed.

## Configuration

Flavour codes and sorting priority are stored in `settings.json`.
